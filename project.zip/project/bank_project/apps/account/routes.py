from apps import app
from flask import request
from apps.account.models import User, Account


@app.route("/client", methods=["POST"])
def create_client():
    name = request.json['name']
    email = request.json['email']
    address = request.json['address']

    user = User(name, email, address)

    user.create()

    return {}, 200

@app.route("/client/account", methods=["POST"])
def create_account():
    user_id = request.json['user_id']
    number = request.json['number']
    amount = request.json['amount']

    account = Account(user_id, number, amount)

    account.create()

    return {}, 200

@app.route("/client/account/statement/<id>", methods=["GET"])
def get_client_account_statement(id):
    account = Account.query.get(id)

    return account.statement(), 200

@app.route("/client/account/deposit/<id>", methods=["PUT"])
def deposit(id):
    account = Account.query.get(id)

    value = request.json['value']

    account.deposit(value)

    account.update()

    return account.statement(), 200


@app.route("/client/account/withdraw/<id>", methods=["PUT"])
def withdraw(id):
    account = Account.query.get(id)

    value = request.json['value']

    result = account.withdraw(value)

    if (result == False):
        return "Insufficient funds", 404
    
    account.update()

    return account.statement(), 200


@app.route("/client/account/transfer/<first_id>/<second_id>", methods=["PUT"])
def transfer(first_id, second_id):
    withdrawal_account = Account.query.get(first_id)
    destiny_account = Account.query.get(second_id)

    value = request.json['value']

    result = withdrawal_account.transfer(destiny_account, value)

    if (result == False):
        return "Insufficient funds", 404
    
    withdrawal_account.update()
    destiny_account.update()

    return withdrawal_account.statement(), 200