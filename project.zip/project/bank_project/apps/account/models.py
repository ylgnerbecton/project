from apps import db


class User(db.Model):
    __tablename__ = 'user'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(120))
    email = db.Column(db.String(120), unique=True)
    address = db.Column(db.String(300))

    def __init__(self, name, email, address):
        self.name = name
        self.email = email
        self.address = address
        
    def persist(self):
        db.session.add(self)
        db.session.commit()

class Account(db.Model):
    __tablename__ = 'account'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    number = db.Column(db.Integer, unique=True)
    amount = db.Column(db.Numeric(10,2))
    
    def __init__(self, user_id, number, amount):
        self.user_id = user_id
        self.number = number
        self.amount = amount

    def deposit(self, value):
        self.amount = self.amount + value
        return self.amount

    def withdraw(self, value):
        if self.amount < value:
            return False

        else: 
            self.amount = self.amount - value
            return True

    def statement(self):
        return str(self.amount)

    def transfer(self, destiny, value):
        removed = self.withdraw(value)
        
        if (removed == False):
            return False
        else:
            destiny.deposit(value)
            return True

    def create(self):
        db.session.add(self)
        db.session.commit()

    def update(self):
        db.session.commit()