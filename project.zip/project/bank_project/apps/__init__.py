from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow


app = Flask(__name__)
app.config.from_object('config')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///bank.db'

db = SQLAlchemy(app)

@app.before_first_request
def create_tables():
    from apps.account.models import User, Account
    db.create_all()

def create_app():
    app.config['TESTING'] = True
    return app

from apps.account import models, routes