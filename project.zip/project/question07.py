def subset(input):
  result=[[]]
  for i in input:
    for value in result:
      result=result+[list(value)+[i]]
  return result

print(subset([1, 2, 4]))

print(subset([0]))
